package dio.boards;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardsApplicationTests {

	@Test
	void contextLoads() {
	}

}
